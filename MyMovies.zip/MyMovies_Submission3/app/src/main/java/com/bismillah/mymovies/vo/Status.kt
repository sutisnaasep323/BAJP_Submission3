package com.bismillah.mymovies.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}