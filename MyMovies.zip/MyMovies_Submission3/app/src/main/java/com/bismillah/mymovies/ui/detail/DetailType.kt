package com.bismillah.mymovies.ui.detail

enum class DetailType {
    MOVIES, TV_SHOWS
}